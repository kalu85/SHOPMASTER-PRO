import 'package:flutter_test/flutter_test.dart';
import 'package:shopmaster_pro/core/models/app_module.dart';
import 'package:shopmaster_pro/main.dart';

void main() {
  test('all 15 modules from the brief are registered', () {
    expect(appModules.length, 15);
    expect(appModules.map((m) => m.id).toSet().length, 15);
  });

  testWidgets('app starts on the dashboard', (tester) async {
    await tester.pumpWidget(const ShopMasterApp());
    expect(find.text('SHOPMASTER PRO'), findsWidgets);
    expect(find.text("Today's Sales"), findsOneWidget);
  });
}
