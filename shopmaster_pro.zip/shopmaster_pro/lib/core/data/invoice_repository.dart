import 'package:sqflite/sqflite.dart';

import '../db/app_database.dart';
import '../models/invoice.dart';

class InvoiceRepository {
  InvoiceRepository._();
  static final InvoiceRepository instance = InvoiceRepository._();

  Future<Database> get _db => AppDatabase.instance.db;

  /// +1 adds stock, -1 removes stock, 0 leaves stock alone.
  ///   sale invoice -> -1, sale return -> +1,
  ///   purchase invoice -> +1, purchase return -> -1, quotation -> 0.
  static int stockDirection(InvoiceKind k, DocType d) {
    if (d == DocType.quotation) return 0;
    final sale = k == InvoiceKind.sale;
    final isReturn = d == DocType.returnNote;
    return (sale != isReturn) ? -1 : 1;
  }

  /// Party balance: invoices add the unpaid amount, returns reduce it.
  static int balanceDirection(DocType d) =>
      d == DocType.returnNote ? -1 : 1;

  /// Saves the document, updates stock and the party balance, all in one
  /// transaction (all or nothing). Returns the new document number.
  Future<String> create(Invoice draft, List<InvoiceItem> items) async {
    final db = await _db;
    return db.transaction((txn) async {
      final now = DateTime.now().toIso8601String();

      // Automatic numbering, never reused.
      final key = '${draft.kind.name}_${docTypeToDb(draft.docType)}';
      final rows =
          await txn.query('counters', where: 'key = ?', whereArgs: [key]);
      final next = (rows.isEmpty ? 0 : (rows.first['value'] as int)) + 1;
      await txn.insert(
        'counters',
        {'key': key, 'value': next},
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      final number =
          '${numberPrefix(draft.kind, draft.docType)}-${next.toString().padLeft(4, '0')}';

      final invoiceId = await txn.insert('invoices', {
        ...draft.toMap(),
        'number': number,
        'created_at': now,
      });

      for (final it in items) {
        await txn.insert('invoice_items', it.toMap(invoiceId));
      }

      // Stock (service items and custom items never change inventory).
      final dir = stockDirection(draft.kind, draft.docType);
      if (dir != 0) {
        for (final it in items) {
          final pid = it.productId;
          if (pid == null) continue;
          final change = dir * it.qty;
          final updated = await txn.rawUpdate(
            'UPDATE products SET current_stock = current_stock + ? '
            'WHERE id = ? AND is_service = 0',
            [change, pid],
          );
          if (updated > 0) {
            await txn.insert('stock_movements', {
              'product_id': pid,
              'qty_change': change,
              'reason': '${docTitle(draft.kind, draft.docType)} $number',
              'note': '',
              'created_at': now,
            });
          }
        }
      }

      // Party balance (quotations never touch it).
      final partyId = draft.partyId;
      if (partyId != null && draft.docType != DocType.quotation) {
        final delta = balanceDirection(draft.docType) * draft.due;
        if (delta != 0) {
          await txn.rawUpdate(
            'UPDATE parties SET current_balance = current_balance + ? '
            'WHERE id = ?',
            [delta, partyId],
          );
        }
      }
      return number;
    });
  }

  Future<List<Invoice>> list(
    InvoiceKind kind,
    DocType docType, {
    String query = '',
  }) async {
    final db = await _db;
    final q = query.trim();
    final rows = await db.query(
      'invoices',
      where: q.isEmpty
          ? 'kind = ? AND doc_type = ?'
          : 'kind = ? AND doc_type = ? AND (number LIKE ? OR party_name LIKE ? OR party_phone LIKE ?)',
      whereArgs: [
        kind.name,
        docTypeToDb(docType),
        if (q.isNotEmpty) ...List.filled(3, '%$q%'),
      ],
      orderBy: 'id DESC',
      limit: 300,
    );
    return rows.map(Invoice.fromMap).toList();
  }

  Future<List<InvoiceItem>> items(int invoiceId) async {
    final db = await _db;
    final rows = await db.query(
      'invoice_items',
      where: 'invoice_id = ?',
      whereArgs: [invoiceId],
      orderBy: 'id',
    );
    return rows.map(InvoiceItem.fromMap).toList();
  }

  /// Latest documents of any kind (invoices and returns, no quotations).
  Future<List<Invoice>> recent({int limit = 5}) async {
    final db = await _db;
    final rows = await db.query(
      'invoices',
      where: "doc_type != 'quotation'",
      orderBy: 'id DESC',
      limit: limit,
    );
    return rows.map(Invoice.fromMap).toList();
  }

  /// Net total for a date (yyyy-MM-dd): invoices minus returns.
  Future<double> netTotalOn(InvoiceKind kind, String isoDate) async {
    final db = await _db;
    final rows = await db.rawQuery(
      "SELECT COALESCE(SUM(CASE doc_type WHEN 'invoice' THEN grand_total "
      "WHEN 'return' THEN -grand_total ELSE 0 END), 0) AS total "
      'FROM invoices WHERE kind = ? AND invoice_date = ?',
      [kind.name, isoDate],
    );
    return (rows.first['total'] as num).toDouble();
  }
}
