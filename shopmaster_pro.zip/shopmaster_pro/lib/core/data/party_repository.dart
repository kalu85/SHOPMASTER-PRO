import 'package:sqflite/sqflite.dart';

import '../db/app_database.dart';
import '../models/party.dart';

class PartyRepository {
  PartyRepository._();
  static final PartyRepository instance = PartyRepository._();

  Future<Database> get _db => AppDatabase.instance.db;

  Future<List<Party>> list(PartyType type, {String query = ''}) async {
    final db = await _db;
    final q = query.trim();
    final rows = q.isEmpty
        ? await db.query(
            'parties',
            where: 'type = ?',
            whereArgs: [type.name],
            orderBy: 'name COLLATE NOCASE',
          )
        : await db.query(
            'parties',
            where:
                'type = ? AND (name LIKE ? OR phone LIKE ? OR email LIKE ? OR gstin LIKE ?)',
            whereArgs: [type.name, ...List.filled(4, '%$q%')],
            orderBy: 'name COLLATE NOCASE',
          );
    return rows.map(Party.fromMap).toList();
  }

  Future<int> insert(Party p) async {
    final db = await _db;
    return db.insert('parties', {
      'type': p.type.name,
      'name': p.name,
      'phone': p.phone,
      'address': p.address,
      'email': p.email,
      'gstin': p.gstin,
      'opening_balance': p.openingBalance,
      'current_balance': p.openingBalance,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  /// Updates contact details only. Balances change through transactions.
  Future<void> update(Party p) async {
    final db = await _db;
    await db.update(
      'parties',
      {
        'name': p.name,
        'phone': p.phone,
        'address': p.address,
        'email': p.email,
        'gstin': p.gstin,
      },
      where: 'id = ?',
      whereArgs: [p.id],
    );
  }

  Future<void> delete(int id) async {
    final db = await _db;
    await db.delete('parties', where: 'id = ?', whereArgs: [id]);
  }

  /// Sum of positive customer balances (money customers owe you).
  Future<double> customerOutstanding() async {
    final db = await _db;
    final rows = await db.rawQuery(
        "SELECT COALESCE(SUM(current_balance), 0) AS total FROM parties WHERE type = 'customer' AND current_balance > 0");
    return (rows.first['total'] as num).toDouble();
  }
}
