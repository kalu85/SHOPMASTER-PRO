import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Local SQLite database (offline-first). Cloud sync comes in Phase 9.
///
/// Version history:
///   1 - products, parties, stock_movements
///   2 - invoices, invoice_items, counters
class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<Database> get db async {
    final existing = _db;
    if (existing != null) return existing;
    final dir = await getDatabasesPath();
    final opened = await openDatabase(
      p.join(dir, 'shopmaster.db'),
      version: 2,
      onConfigure: (d) async {
        await d.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (d, version) async {
        await _createV1(d);
        await _createV2(d);
      },
      onUpgrade: (d, oldVersion, newVersion) async {
        if (oldVersion < 2) await _createV2(d);
      },
    );
    _db = opened;
    return opened;
  }

  Future<void> _createV1(Database d) async {
    await d.execute('''
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT '',
        hsn TEXT NOT NULL DEFAULT '',
        barcode TEXT UNIQUE,
        purchase_rate REAL NOT NULL DEFAULT 0,
        sale_rate REAL NOT NULL DEFAULT 0,
        gst_rate INTEGER NOT NULL DEFAULT 0,
        opening_stock REAL NOT NULL DEFAULT 0,
        current_stock REAL NOT NULL DEFAULT 0,
        min_stock REAL NOT NULL DEFAULT 0,
        is_service INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      )
    ''');
    await d.execute('CREATE INDEX idx_products_name ON products(name)');

    await d.execute('''
      CREATE TABLE parties (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT NOT NULL CHECK (type IN ('customer', 'supplier')),
        name TEXT NOT NULL,
        phone TEXT NOT NULL DEFAULT '',
        address TEXT NOT NULL DEFAULT '',
        email TEXT NOT NULL DEFAULT '',
        gstin TEXT NOT NULL DEFAULT '',
        opening_balance REAL NOT NULL DEFAULT 0,
        current_balance REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      )
    ''');
    await d.execute('CREATE INDEX idx_parties_type_name ON parties(type, name)');

    await d.execute('''
      CREATE TABLE stock_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        qty_change REAL NOT NULL,
        reason TEXT NOT NULL,
        note TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL
      )
    ''');
    await d.execute(
        'CREATE INDEX idx_movements_product ON stock_movements(product_id)');
  }

  Future<void> _createV2(Database d) async {
    await d.execute('''
      CREATE TABLE invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kind TEXT NOT NULL CHECK (kind IN ('sale', 'purchase')),
        doc_type TEXT NOT NULL CHECK (doc_type IN ('invoice', 'quotation', 'return')),
        number TEXT NOT NULL,
        party_id INTEGER REFERENCES parties(id) ON DELETE SET NULL,
        party_name TEXT NOT NULL DEFAULT '',
        party_phone TEXT NOT NULL DEFAULT '',
        party_address TEXT NOT NULL DEFAULT '',
        party_gstin TEXT NOT NULL DEFAULT '',
        is_gst INTEGER NOT NULL DEFAULT 0,
        is_interstate INTEGER NOT NULL DEFAULT 0,
        invoice_date TEXT NOT NULL,
        subtotal REAL NOT NULL DEFAULT 0,
        discount_total REAL NOT NULL DEFAULT 0,
        taxable_total REAL NOT NULL DEFAULT 0,
        cgst REAL NOT NULL DEFAULT 0,
        sgst REAL NOT NULL DEFAULT 0,
        igst REAL NOT NULL DEFAULT 0,
        grand_total REAL NOT NULL DEFAULT 0,
        paid REAL NOT NULL DEFAULT 0,
        due REAL NOT NULL DEFAULT 0,
        pay_mode TEXT NOT NULL DEFAULT 'Cash',
        notes TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        UNIQUE (kind, doc_type, number)
      )
    ''');
    await d.execute(
        'CREATE INDEX idx_invoices_kind_date ON invoices(kind, invoice_date)');

    await d.execute('''
      CREATE TABLE invoice_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
        product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
        name TEXT NOT NULL,
        hsn TEXT NOT NULL DEFAULT '',
        qty REAL NOT NULL,
        rate REAL NOT NULL,
        discount REAL NOT NULL DEFAULT 0,
        gst_rate INTEGER NOT NULL DEFAULT 0,
        taxable REAL NOT NULL DEFAULT 0,
        cgst REAL NOT NULL DEFAULT 0,
        sgst REAL NOT NULL DEFAULT 0,
        igst REAL NOT NULL DEFAULT 0,
        amount REAL NOT NULL DEFAULT 0
      )
    ''');
    await d.execute(
        'CREATE INDEX idx_items_invoice ON invoice_items(invoice_id)');

    // Running invoice numbers. Never reused, even if invoices are removed.
    await d.execute('''
      CREATE TABLE counters (
        key TEXT PRIMARY KEY,
        value INTEGER NOT NULL
      )
    ''');
  }
}
