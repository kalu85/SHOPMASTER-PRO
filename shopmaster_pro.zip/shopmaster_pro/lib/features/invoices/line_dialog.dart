import 'package:flutter/material.dart';

import '../../core/models/product.dart';
import '../../core/utils/format.dart';
import '../stock/product_form_screen.dart' show kGstRates;

/// One editable row of an invoice that has not been saved yet.
class DraftLine {
  DraftLine({
    this.product,
    required this.name,
    this.hsn = '',
    this.qty = 1,
    required this.rate,
    this.discount = 0,
    this.gstRate = 0,
  });

  final Product? product;
  String name;
  String hsn;
  double qty;
  double rate;

  /// Rupee discount for the whole line.
  double discount;
  int gstRate;

  DraftLine copy() => DraftLine(
        product: product,
        name: name,
        hsn: hsn,
        qty: qty,
        rate: rate,
        discount: discount,
        gstRate: gstRate,
      );
}

Future<DraftLine?> showLineDialog(
  BuildContext context,
  DraftLine line, {
  required bool showGst,
}) {
  return showDialog<DraftLine>(
    context: context,
    builder: (_) => _LineDialog(line: line, showGst: showGst),
  );
}

class _LineDialog extends StatefulWidget {
  const _LineDialog({required this.line, required this.showGst});

  final DraftLine line;
  final bool showGst;

  @override
  State<_LineDialog> createState() => _LineDialogState();
}

class _LineDialogState extends State<_LineDialog> {
  late final TextEditingController _name;
  late final TextEditingController _hsn;
  late final TextEditingController _qty;
  late final TextEditingController _rate;
  late final TextEditingController _discount;
  late int _gst;
  String? _error;

  bool get _custom => widget.line.product == null;

  @override
  void initState() {
    super.initState();
    final l = widget.line;
    _name = TextEditingController(text: l.name);
    _hsn = TextEditingController(text: l.hsn);
    _qty = TextEditingController(text: fmtQty(l.qty));
    _rate = TextEditingController(text: l.rate == 0 ? '' : fmtQty(l.rate));
    _discount =
        TextEditingController(text: l.discount == 0 ? '' : fmtQty(l.discount));
    _gst = kGstRates.contains(l.gstRate) ? l.gstRate : 0;
  }

  @override
  void dispose() {
    _name.dispose();
    _hsn.dispose();
    _qty.dispose();
    _rate.dispose();
    _discount.dispose();
    super.dispose();
  }

  void _ok() {
    final qty = double.tryParse(_qty.text.trim());
    final rate = double.tryParse(_rate.text.trim());
    final disc = double.tryParse(_discount.text.trim()) ?? 0;
    if (_custom && _name.text.trim().isEmpty) {
      setState(() => _error = 'Enter an item name');
      return;
    }
    if (qty == null || qty <= 0) {
      setState(() => _error = 'Quantity must be greater than zero');
      return;
    }
    if (rate == null || rate < 0) {
      setState(() => _error = 'Enter a valid rate');
      return;
    }
    if (disc < 0) {
      setState(() => _error = 'Discount cannot be negative');
      return;
    }
    final out = widget.line.copy()
      ..name = _custom ? _name.text.trim() : widget.line.name
      ..hsn = _hsn.text.trim()
      ..qty = qty
      ..rate = rate
      ..discount = disc
      ..gstRate = _gst;
    Navigator.of(context).pop(out);
  }

  InputDecoration _dec(String label) =>
      InputDecoration(labelText: label, border: const OutlineInputBorder());

  @override
  Widget build(BuildContext context) {
    const numKb = TextInputType.numberWithOptions(decimal: true);
    return AlertDialog(
      title: Text(_custom ? 'Custom item' : widget.line.name),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_custom) ...[
              TextField(controller: _name, decoration: _dec('Item name')),
              const SizedBox(height: 12),
            ],
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _qty,
                    keyboardType: numKb,
                    decoration: _dec('Qty'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: _rate,
                    keyboardType: numKb,
                    decoration: _dec('Rate (₹)'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _discount,
              keyboardType: numKb,
              decoration: _dec('Discount (₹, whole line)'),
            ),
            if (widget.showGst) ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(controller: _hsn, decoration: _dec('HSN / SAC')),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: DropdownButtonFormField<int>(
                      initialValue: _gst,
                      decoration: _dec('GST rate'),
                      items: [
                        for (final r in kGstRates)
                          DropdownMenuItem(value: r, child: Text('$r%')),
                      ],
                      onChanged: (v) => setState(() => _gst = v ?? 0),
                    ),
                  ),
                ],
              ),
            ],
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!, style: const TextStyle(color: Colors.red)),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(onPressed: _ok, child: const Text('OK')),
      ],
    );
  }
}
