import 'package:flutter/material.dart';

import '../../core/data/invoice_repository.dart';
import '../../core/models/invoice.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/serials.dart';
import 'invoice_pdf_screen.dart';

/// Read-only view of a saved document with PDF, print and share.
class InvoiceDetailScreen extends StatelessWidget {
  const InvoiceDetailScreen({super.key, required this.invoice});

  final Invoice invoice;

  Widget _row(String label, double value, {bool bold = false, Color? color}) {
    final style = TextStyle(
      fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
      fontSize: bold ? 17 : 14,
      color: color,
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(child: Text(label, style: style)),
          Text(inr.format(value), style: style),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final inv = invoice;
    final isSale = inv.kind == InvoiceKind.sale;
    final accent = isSale ? AppColors.sales : AppColors.purchases;
    final isQuotation = inv.docType == DocType.quotation;
    final party = inv.partyName.isEmpty
        ? (isSale ? 'Walk-in customer' : 'No supplier')
        : inv.partyName;

    return Scaffold(
      appBar: AppBar(
        title: Text(inv.number),
        actions: [
          IconButton(
            tooltip: 'PDF / Print / Share',
            icon: const Icon(Icons.picture_as_pdf_rounded),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => InvoicePdfScreen(invoice: inv))),
          ),
        ],
      ),
      body: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            docTitle(inv.kind, inv.docType),
                            style: TextStyle(
                              color: accent,
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                            ),
                          ),
                          const Spacer(),
                          Chip(
                            label: Text(inv.isGst ? 'GST' : 'NON-GST'),
                            visualDensity: VisualDensity.compact,
                          ),
                        ],
                      ),
                      Text(
                        prettyDate(inv.invoiceDate),
                        style: const TextStyle(color: AppColors.textMuted),
                      ),
                      const Divider(height: 24),
                      Text(
                        party,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 16,
                        ),
                      ),
                      if (inv.partyPhone.isNotEmpty) Text(inv.partyPhone),
                      if (inv.partyAddress.isNotEmpty) Text(inv.partyAddress),
                      if (inv.isGst && inv.partyGstin.isNotEmpty)
                        Text('GSTIN: ${inv.partyGstin}'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FutureBuilder<List<InvoiceItem>>(
                future: InvoiceRepository.instance.items(inv.id!),
                builder: (context, snap) {
                  if (snap.connectionState != ConnectionState.done) {
                    return const Padding(
                      padding: EdgeInsets.all(24),
                      child: Center(child: CircularProgressIndicator()),
                    );
                  }
                  if (snap.hasError) {
                    return Text('Could not load items: ${snap.error}');
                  }
                  final items = snap.data ?? [];
                  return Column(
                    children: [
                      for (var i = 0; i < items.length; i++)
                        Card(
                          child: ListTile(
                            leading: Text('${i + 1}'),
                            title: Text(
                              items[i].name,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w700),
                            ),
                            subtitle: Text(
                              [
                                '${fmtQty(items[i].qty)} × ${inr.format(items[i].rate)}',
                                if (items[i].discount > 0)
                                  'Disc ${inr.format(items[i].discount)}',
                                if (inv.isGst) 'GST ${items[i].gstRate}%',
                                if (inv.isGst && items[i].hsn.isNotEmpty)
                                  'HSN ${items[i].hsn}',
                                if (items[i].serials.isNotEmpty)
                                  'Serial ${items[i].serials}',
                                if (items[i].warrantyMonths > 0)
                                  'Warranty ${warrantyLabel(items[i].warrantyMonths)}',
                              ].join('  •  '),
                            ),
                            trailing: Text(
                              inr.format(items[i].amount),
                              style:
                                  const TextStyle(fontWeight: FontWeight.w700),
                            ),
                          ),
                        ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _row('Subtotal', inv.subtotal),
                      if (inv.discountTotal > 0)
                        _row('Discount', -inv.discountTotal),
                      if (inv.isGst) ...[
                        _row('Taxable amount', inv.taxableTotal),
                        if (inv.isInterstate)
                          _row('IGST', inv.igst)
                        else ...[
                          _row('CGST', inv.cgst),
                          _row('SGST', inv.sgst),
                        ],
                        _row('Total GST', inv.totalGst),
                      ],
                      const Divider(),
                      _row('Grand total', inv.grandTotal, bold: true),
                      if (!isQuotation) ...[
                        const SizedBox(height: 6),
                        _row(
                          inv.docType == DocType.returnNote
                              ? 'Refunded'
                              : (isSale ? 'Received' : 'Paid'),
                          inv.paid,
                        ),
                        _row(
                          'Due amount',
                          inv.due,
                          bold: true,
                          color: inv.due > 0 ? AppColors.reports : null,
                        ),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Payment mode: ${inv.payMode}',
                            style: const TextStyle(color: AppColors.textMuted),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => InvoicePdfScreen(invoice: inv))),
                icon: const Icon(Icons.picture_as_pdf_rounded),
                label: const Text('PDF  •  Print  •  Share'),
              ),
              if (inv.notes.isNotEmpty) ...[
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text('Notes: ${inv.notes}'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
