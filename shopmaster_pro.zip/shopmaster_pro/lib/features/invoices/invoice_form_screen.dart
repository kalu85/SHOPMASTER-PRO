import 'package:flutter/material.dart';

import '../../core/data/account_repository.dart';
import '../../core/data/invoice_repository.dart';
import '../../core/data/party_repository.dart';
import '../../core/data/product_repository.dart';
import '../../core/data/settings_repository.dart';
import '../../core/models/account.dart';
import '../../core/models/serial.dart';
import '../../core/utils/serials.dart';
import '../../core/models/invoice.dart';
import '../../core/models/party.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/gst_calculator.dart';
import 'line_dialog.dart';
import 'pickers.dart';

/// Create a sales/purchase invoice, quotation or return.
class InvoiceFormScreen extends StatefulWidget {
  const InvoiceFormScreen({
    super.key,
    required this.kind,
    required this.docType,
    this.existing,
  });

  final InvoiceKind kind;
  final DocType docType;

  /// When set, the screen edits this saved document instead of creating one.
  final Invoice? existing;

  @override
  State<InvoiceFormScreen> createState() => _InvoiceFormScreenState();
}

class _InvoiceFormScreenState extends State<InvoiceFormScreen> {
  final List<DraftLine> _lines = [];
  final _paid = TextEditingController();
  final _notes = TextEditingController();
  Party? _party;
  bool _isGst = true;
  bool _interstate = false;
  DateTime _date = DateTime.now();
  String _mode = 'Cash';
  bool _saving = false;
  List<Account> _accounts = [];
  int? _accountId;

  bool get _isSale => widget.kind == InvoiceKind.sale;
  bool get _isQuotation => widget.docType == DocType.quotation;
  bool get _isReturn => widget.docType == DocType.returnNote;

  /// Serial numbers are not tracked on quotations.
  bool get _serialsAllowed => !_isQuotation;
  Color get _color => _isSale ? AppColors.sales : AppColors.purchases;
  PartyType get _partyType =>
      _isSale ? PartyType.customer : PartyType.supplier;
  String get _partyNoun => _isSale ? 'customer' : 'supplier';

  @override
  void initState() {
    super.initState();
    if (widget.existing != null) {
      _loadExisting(widget.existing!);
    } else {
      _loadDefaults();
    }
  }

  bool get _editing => widget.existing != null;

  Future<void> _loadExisting(Invoice inv) async {
    try {
      final accs = await AccountRepository.instance.accounts();
      final items = await InvoiceRepository.instance.items(inv.id!);
      Party? party;
      if (inv.partyId != null) {
        party = await PartyRepository.instance.byId(inv.partyId!);
      }
      final lines = <DraftLine>[];
      for (final it in items) {
        final prod = it.productId == null
            ? null
            : await ProductRepository.instance.byId(it.productId!);
        lines.add(DraftLine(
          product: prod,
          name: it.name,
          hsn: it.hsn,
          qty: it.qty,
          rate: it.rate,
          discount: it.discount,
          gstRate: it.gstRate,
          serials: it.serials,
          warrantyMonths: it.warrantyMonths,
        ));
      }
      if (!mounted) return;
      setState(() {
        _accounts = accs;
        _party = party;
        _isGst = inv.isGst;
        _interstate = inv.isInterstate;
        _date = DateTime.tryParse(inv.invoiceDate) ?? DateTime.now();
        _mode = inv.payMode == 'Credit' ? 'Cash' : inv.payMode;
        _accountId = inv.accountId ?? _defaultAccountFor(_mode);
        _paid.text = inv.paid == 0 ? '' : fmtQty(inv.paid);
        _notes.text = inv.notes;
        _lines
          ..clear()
          ..addAll(lines);
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Could not open for editing: $e')));
    }
  }

  Future<void> _loadDefaults() async {
    try {
      final shop = await SettingsRepository.instance.load();
      final accs = await AccountRepository.instance.accounts();
      if (!mounted) return;
      setState(() {
        _isGst = shop.defaultGst;
        _mode = kPayModes.contains(shop.defaultPayMode) &&
                shop.defaultPayMode != 'Credit'
            ? shop.defaultPayMode
            : 'Cash';
        _accounts = accs;
        _accountId = _defaultAccountFor(_mode);
      });
    } catch (_) {
      // Defaults are a convenience only.
    }
  }

  /// Cash goes to the cash drawer; UPI/Bank/Card go to the first bank
  /// account if there is one.
  int? _defaultAccountFor(String mode) {
    if (_accounts.isEmpty) return null;
    final cash = _accounts.where((a) => a.isCash).toList();
    final banks = _accounts.where((a) => !a.isCash).toList();
    if (mode == 'Cash' || banks.isEmpty) {
      return (cash.isNotEmpty ? cash.first : _accounts.first).id;
    }
    return banks.first.id;
  }

  @override
  void dispose() {
    _paid.dispose();
    _notes.dispose();
    super.dispose();
  }

  InvoiceTotals get _totals => GstCalculator.totals(
        [
          for (final l in _lines)
            LineInput(
              qty: l.qty,
              rate: l.rate,
              discount: l.discount,
              gstRate: l.gstRate,
            ),
        ],
        isGst: _isGst,
        isInterstate: _isGst && _interstate,
      );

  double get _paidValue => double.tryParse(_paid.text.trim()) ?? 0;

  Future<void> _pickParty() async {
    final choice = await pickParty(context, _partyType);
    if (choice == null || !mounted) return;
    setState(() => _party = choice.party);
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (d != null && mounted) setState(() => _date = d);
  }

  Future<void> _addItem() async {
    final choice = await pickProduct(context);
    if (choice == null || !mounted) return;
    final p = choice.product;
    if (p == null) {
      final line = await showLineDialog(
        context,
        DraftLine(name: '', rate: 0),
        showGst: _isGst,
        showSerials: _serialsAllowed,
        showWarranty: _isSale && _serialsAllowed,
      );
      if (line != null && mounted) setState(() => _lines.add(line));
      return;
    }
    final existing = _lines.indexWhere((l) => l.product?.id == p.id);
    if (existing >= 0) {
      setState(() => _lines[existing].qty += 1);
      return;
    }
    setState(() {
      _lines.add(DraftLine(
        product: p,
        name: p.name,
        hsn: p.hsn,
        rate: _isSale ? p.saleRate : p.purchaseRate,
        gstRate: p.gstRate,
      ));
    });
  }

  Future<void> _editLine(int i) async {
    final edited = await showLineDialog(
      context,
      _lines[i],
      showGst: _isGst,
      showSerials: _serialsAllowed,
      showWarranty: _isSale && _serialsAllowed,
    );
    if (edited != null && mounted) setState(() => _lines[i] = edited);
  }

  String? _validate(InvoiceTotals t) {
    if (_lines.isEmpty) return 'Add at least one item';
    if (t.grandTotal <= 0) return 'The total must be greater than zero';
    for (final l in _lines) {
      final n = parseSerials(l.serials).length;
      if (n > 0 && n != l.qty.round()) {
        return '${l.name}: ${l.qty.round()} item(s) but $n serial number(s)';
      }
    }
    if (!_isQuotation) {
      final paid = _paidValue;
      if (paid < 0) return 'Amount cannot be negative';
      if (paid > t.grandTotal) return 'Amount cannot be more than the total';
      final due = round2(t.grandTotal - paid);
      if (due > 0 && _party == null) {
        return 'Select a $_partyNoun to keep a due amount, or enter the full amount';
      }
    }
    return null;
  }

  Future<void> _save() async {
    final t = _totals;
    final error = _validate(t);
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
      return;
    }
    setState(() => _saving = true);
    final paid = _isQuotation ? 0.0 : _paidValue;
    final party = _party;
    final invoice = Invoice(
      kind: widget.kind,
      docType: widget.docType,
      partyId: party?.id,
      partyName: party?.name ?? '',
      partyPhone: party?.phone ?? '',
      partyAddress: party?.address ?? '',
      partyGstin: party?.gstin ?? '',
      isGst: _isGst,
      isInterstate: _isGst && _interstate,
      invoiceDate: isoDateFmt.format(_date),
      subtotal: t.subtotal,
      discountTotal: t.discountTotal,
      taxableTotal: t.taxable,
      cgst: t.cgst,
      sgst: t.sgst,
      igst: t.igst,
      grandTotal: t.grandTotal,
      paid: paid,
      payMode: paid == 0 ? 'Credit' : _mode,
      accountId: paid == 0 ? null : _accountId,
      notes: _notes.text.trim(),
    );
    final items = <InvoiceItem>[
      for (var i = 0; i < _lines.length; i++)
        InvoiceItem(
          productId: _lines[i].product?.id,
          name: _lines[i].name,
          hsn: _lines[i].hsn,
          qty: _lines[i].qty,
          rate: _lines[i].rate,
          discount: t.lines[i].discount,
          gstRate: _isGst ? _lines[i].gstRate : 0,
          taxable: t.lines[i].taxable,
          cgst: t.lines[i].cgst,
          sgst: t.lines[i].sgst,
          igst: t.lines[i].igst,
          amount: t.lines[i].amount,
          serials: _lines[i].serials,
          warrantyMonths: _isSale ? _lines[i].warrantyMonths : 0,
        ),
    ];
    try {
      final String number;
      if (_editing) {
        await InvoiceRepository.instance
            .update(widget.existing!.id!, invoice, items);
        number = widget.existing!.number;
      } else {
        number = await InvoiceRepository.instance.create(invoice, items);
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_editing ? 'Updated $number' : 'Saved $number')));
      Navigator.of(context).pop(true);
    } on SerialException catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Serial number problem: ${e.message}')));
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Could not save: $e')));
    }
  }

  Widget _totalRow(String label, double value, {bool bold = false}) {
    final style = TextStyle(
      fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
      fontSize: bold ? 17 : 14,
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(child: Text(label, style: style)),
          Text(inr.format(value), style: style),
        ],
      ),
    );
  }

  Widget _lineTile(int i, LineResult r) {
    final l = _lines[i];
    final p = l.product;
    final goesNegative = _isSale &&
        widget.docType == DocType.invoice &&
        p != null &&
        !p.isService &&
        l.qty > p.currentStock;
    final sub = StringBuffer('${fmtQty(l.qty)} × ${inr.format(l.rate)}');
    if (r.discount > 0) sub.write('  •  Disc ${inr.format(r.discount)}');
    if (_isGst) sub.write('  •  GST ${l.gstRate}%');
    final sn = parseSerials(l.serials);
    if (sn.isNotEmpty) sub.write('\nSerial: ${sn.join(', ')}');
    if (_isSale && l.warrantyMonths > 0) {
      sub.write('\nWarranty: ${warrantyLabel(l.warrantyMonths)}');
    }
    return Card(
      child: ListTile(
        onTap: () => _editLine(i),
        title: Text(l.name, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(sub.toString()),
            if (goesNegative)
              Text(
                'Stock will go negative: ${fmtQty(p!.currentStock - l.qty)}',
                style: const TextStyle(
                  color: AppColors.reports,
                  fontWeight: FontWeight.w600,
                ),
              ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              inr.format(r.amount),
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            IconButton(
              tooltip: 'Remove',
              icon: const Icon(Icons.close_rounded),
              onPressed: () => setState(() => _lines.removeAt(i)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = _totals;
    final due = round2(t.grandTotal - _paidValue);
    final title = docTitle(widget.kind, widget.docType);
    return Scaffold(
      appBar: AppBar(
          title: Text(_editing ? 'Edit ${widget.existing!.number}' : 'New $title')),
      body: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // Party
              Card(
                child: ListTile(
                  onTap: _pickParty,
                  leading: Icon(Icons.person_rounded, color: _color),
                  title: Text(
                    _party?.name ??
                        (_isSale ? 'Walk-in customer' : 'No supplier selected'),
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: Text(
                    _party == null
                        ? 'Tap to choose a $_partyNoun'
                        : [
                            if (_party!.phone.isNotEmpty) _party!.phone,
                            if (_party!.gstin.isNotEmpty) _party!.gstin,
                          ].join('  •  '),
                  ),
                  trailing: const Icon(Icons.chevron_right_rounded),
                ),
              ),
              const SizedBox(height: 12),
              // GST mode, supply type and date
              Wrap(
                spacing: 12,
                runSpacing: 8,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment(value: true, label: Text('GST')),
                      ButtonSegment(value: false, label: Text('NON-GST')),
                    ],
                    selected: {_isGst},
                    onSelectionChanged: (s) =>
                        setState(() => _isGst = s.first),
                  ),
                  OutlinedButton.icon(
                    onPressed: _pickDate,
                    icon: const Icon(Icons.calendar_today_rounded, size: 18),
                    label: Text(dateFmt.format(_date)),
                  ),
                ],
              ),
              if (_isGst)
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Interstate supply (IGST)'),
                  subtitle: Text(
                    _interstate
                        ? 'Tax is charged as IGST'
                        : 'Tax is split into CGST + SGST',
                  ),
                  value: _interstate,
                  onChanged: (v) => setState(() => _interstate = v),
                ),
              const SizedBox(height: 8),
              // Items
              Row(
                children: [
                  Text('Items', style: Theme.of(context).textTheme.titleMedium),
                  const Spacer(),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: _color),
                    onPressed: _addItem,
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('Add item'),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              if (_lines.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: Center(
                    child: Text(
                      'No items yet. Tap "Add item".',
                      style: TextStyle(color: AppColors.textMuted),
                    ),
                  ),
                )
              else
                for (var i = 0; i < _lines.length; i++) _lineTile(i, t.lines[i]),
              const SizedBox(height: 12),
              // Totals
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _totalRow('Subtotal', t.subtotal),
                      if (t.discountTotal > 0)
                        _totalRow('Discount', -t.discountTotal),
                      if (_isGst) ...[
                        _totalRow('Taxable amount', t.taxable),
                        if (_interstate)
                          _totalRow('IGST', t.igst)
                        else ...[
                          _totalRow('CGST', t.cgst),
                          _totalRow('SGST', t.sgst),
                        ],
                      ],
                      const Divider(),
                      _totalRow('Grand total', t.grandTotal, bold: true),
                    ],
                  ),
                ),
              ),
              if (!_isQuotation) ...[
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _isReturn
                              ? 'Refund'
                              : (_isSale ? 'Payment received' : 'Payment made'),
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: _paid,
                                onChanged: (_) => setState(() {}),
                                keyboardType:
                                    const TextInputType.numberWithOptions(
                                        decimal: true),
                                decoration: const InputDecoration(
                                  labelText: 'Amount (₹)',
                                  border: OutlineInputBorder(),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            TextButton(
                              onPressed: () => setState(
                                  () => _paid.text = fmtQty(t.grandTotal)),
                              child: const Text('Full'),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        DropdownButtonFormField<String>(
                          initialValue: _mode,
                          decoration: const InputDecoration(
                            labelText: 'Payment mode',
                            border: OutlineInputBorder(),
                          ),
                          items: [
                            for (final m in kPayModes)
                              DropdownMenuItem(value: m, child: Text(m)),
                          ],
                          onChanged: (v) => setState(() {
                            _mode = v ?? 'Cash';
                            _accountId = _defaultAccountFor(_mode);
                          }),
                        ),
                        if (_accounts.isNotEmpty) ...[
                          const SizedBox(height: 12),
                          DropdownButtonFormField<int>(
                            key: ValueKey('acc$_accountId'),
                            initialValue: _accountId,
                            decoration: InputDecoration(
                              labelText: _isSale
                                  ? 'Money goes into'
                                  : 'Money comes from',
                              border: const OutlineInputBorder(),
                            ),
                            items: [
                              for (final a in _accounts)
                                DropdownMenuItem(
                                    value: a.id, child: Text(a.name)),
                            ],
                            onChanged: (v) => setState(() => _accountId = v),
                          ),
                        ],
                        const SizedBox(height: 10),
                        _totalRow('Due amount', due < 0 ? 0 : due, bold: true),
                      ],
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 12),
              TextField(
                controller: _notes,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Notes (optional)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: _color),
                onPressed: _saving ? null : _save,
                child: Text(_saving
                    ? 'Saving...'
                    : (_editing ? 'Save changes' : 'Save $title')),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}
