import 'package:flutter/material.dart';

import '../../core/data/party_repository.dart';
import '../../core/data/product_repository.dart';
import '../../core/models/party.dart';
import '../../core/models/product.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/format.dart';

/// Result of the party picker. [party] null means walk-in (no party).
class PartyChoice {
  const PartyChoice(this.party);
  final Party? party;
}

/// Result of the item picker. [product] null means a custom item.
class ProductChoice {
  const ProductChoice(this.product);
  final Product? product;
}

Future<PartyChoice?> pickParty(BuildContext context, PartyType type) {
  return showModalBottomSheet<PartyChoice>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => _PartySheet(type: type),
  );
}

Future<ProductChoice?> pickProduct(BuildContext context) {
  return showModalBottomSheet<ProductChoice>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => const _ProductSheet(),
  );
}

class _PartySheet extends StatefulWidget {
  const _PartySheet({required this.type});

  final PartyType type;

  @override
  State<_PartySheet> createState() => _PartySheetState();
}

class _PartySheetState extends State<_PartySheet> {
  final _search = TextEditingController();
  List<Party> _items = [];
  bool _loading = true;

  bool get _isCustomer => widget.type == PartyType.customer;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final items =
        await PartyRepository.instance.list(widget.type, query: _search.text);
    if (!mounted) return;
    setState(() {
      _items = items;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final noun = _isCustomer ? 'customer' : 'supplier';
    return SizedBox(
      height: MediaQuery.sizeOf(context).height * 0.75,
      child: Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.viewInsetsOf(context).bottom,
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: TextField(
                controller: _search,
                onChanged: (_) => _load(),
                decoration: InputDecoration(
                  hintText: 'Search $noun',
                  prefixIcon: const Icon(Icons.search_rounded),
                  border: const OutlineInputBorder(),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person_off_rounded),
              title: Text(_isCustomer ? 'Walk-in customer' : 'No supplier'),
              subtitle: const Text('No party, no due amount'),
              onTap: () => Navigator.of(context).pop(const PartyChoice(null)),
            ),
            const Divider(height: 1),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _items.isEmpty
                      ? Center(
                          child: Text(
                            'No ${noun}s found. Add one in Party Details.',
                            style: const TextStyle(color: AppColors.textMuted),
                          ),
                        )
                      : ListView.builder(
                          itemCount: _items.length,
                          itemBuilder: (context, i) {
                            final p = _items[i];
                            return ListTile(
                              title: Text(p.name),
                              subtitle: Text(
                                [
                                  if (p.phone.isNotEmpty) p.phone,
                                  if (p.gstin.isNotEmpty) p.gstin,
                                ].join('  •  '),
                              ),
                              onTap: () =>
                                  Navigator.of(context).pop(PartyChoice(p)),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProductSheet extends StatefulWidget {
  const _ProductSheet();

  @override
  State<_ProductSheet> createState() => _ProductSheetState();
}

class _ProductSheetState extends State<_ProductSheet> {
  final _search = TextEditingController();
  List<Product> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final items = await ProductRepository.instance.list(query: _search.text);
    if (!mounted) return;
    setState(() {
      _items = items;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.sizeOf(context).height * 0.75,
      child: Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.viewInsetsOf(context).bottom,
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: TextField(
                controller: _search,
                onChanged: (_) => _load(),
                decoration: const InputDecoration(
                  hintText: 'Search name, HSN or barcode',
                  prefixIcon: Icon(Icons.search_rounded),
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.edit_note_rounded),
              title: const Text('Custom item'),
              subtitle: const Text('Type a name and price (no stock change)'),
              onTap: () => Navigator.of(context).pop(const ProductChoice(null)),
            ),
            const Divider(height: 1),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _items.isEmpty
                      ? const Center(
                          child: Text(
                            'No items found. Add items in Items & Stock.',
                            style: TextStyle(color: AppColors.textMuted),
                          ),
                        )
                      : ListView.builder(
                          itemCount: _items.length,
                          itemBuilder: (context, i) {
                            final p = _items[i];
                            return ListTile(
                              title: Text(p.name),
                              subtitle: Text(
                                p.isService
                                    ? 'Service  •  GST ${p.gstRate}%'
                                    : 'Stock ${fmtQty(p.currentStock)}  •  GST ${p.gstRate}%',
                              ),
                              trailing: Text(
                                inr.format(p.saleRate),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              onTap: () =>
                                  Navigator.of(context).pop(ProductChoice(p)),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}
