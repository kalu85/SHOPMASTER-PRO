import 'package:flutter/material.dart';

import '../../core/data/party_repository.dart';
import '../../core/data/product_repository.dart';
import '../../core/models/product.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/format.dart';
import '../../core/widgets/stat_card.dart';

/// Overview screen. Stock and outstanding figures are live (Phase 2);
/// sales, purchases, cash and bank stay at zero until later phases.
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key, required this.onOpenModule});

  /// Navigates to a module by its id (see appModules).
  final void Function(String moduleId) onOpenModule;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _stockItems = 0;
  double _outstanding = 0;
  List<Product> _lowStock = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final items = await ProductRepository.instance.count();
      final low = await ProductRepository.instance.lowStock();
      final out = await PartyRepository.instance.customerOutstanding();
      if (!mounted) return;
      setState(() {
        _stockItems = items;
        _lowStock = low;
        _outstanding = out;
      });
    } catch (_) {
      // Database unavailable (e.g. in tests): keep the zero values.
    }
  }

  @override
  Widget build(BuildContext context) {
    final onOpenModule = widget.onOpenModule;
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final columns = width >= 1100 ? 3 : (width >= 640 ? 2 : 1);
        const gap = 14.0;
        final cardWidth = (width - 32 - gap * (columns - 1)) / columns;
        final halfWidth =
            columns == 1 ? width - 32 : (width - 32 - gap) / 2;

        final stats = <Widget>[
          StatCard(
            label: "Today's Sales",
            value: inr.format(0),
            icon: Icons.trending_up_rounded,
            color: AppColors.sales,
            onTap: () => onOpenModule('sale'),
          ),
          StatCard(
            label: "Today's Purchases",
            value: inr.format(0),
            icon: Icons.shopping_bag_rounded,
            color: AppColors.purchases,
            onTap: () => onOpenModule('purchase'),
          ),
          StatCard(
            label: 'Total Outstanding',
            value: inr.format(_outstanding),
            icon: Icons.hourglass_bottom_rounded,
            color: AppColors.reports,
            onTap: () => onOpenModule('parties'),
          ),
          StatCard(
            label: 'Cash Balance',
            value: inr.format(0),
            icon: Icons.payments_rounded,
            color: AppColors.bankUpi,
            onTap: () => onOpenModule('cashbank'),
          ),
          StatCard(
            label: 'Bank Balance',
            value: inr.format(0),
            icon: Icons.account_balance_rounded,
            color: AppColors.suppliers,
            onTap: () => onOpenModule('cashbank'),
          ),
          StatCard(
            label: 'Total Stock Items',
            value: '$_stockItems',
            icon: Icons.inventory_2_rounded,
            color: AppColors.stock,
            onTap: () => onOpenModule('stock'),
          ),
        ];

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _QuickActions(onOpenModule: onOpenModule),
            const SizedBox(height: 16),
            Wrap(
              spacing: gap,
              runSpacing: gap,
              children: [
                for (final s in stats) SizedBox(width: cardWidth, child: s),
              ],
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: gap,
              runSpacing: gap,
              children: [
                SizedBox(
                  width: halfWidth,
                  child: _LowStockCard(products: _lowStock),
                ),
                SizedBox(
                  width: halfWidth,
                  child: const _EmptyListCard(
                    title: 'Recent Invoices',
                    icon: Icons.description_rounded,
                    color: AppColors.sales,
                    message: 'No invoices yet.',
                  ),
                ),
                SizedBox(
                  width: width - 32,
                  child: const _EmptyListCard(
                    title: 'Recent Transactions',
                    icon: Icons.swap_horiz_rounded,
                    color: AppColors.bankUpi,
                    message: 'No transactions yet.',
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _QuickActions extends StatelessWidget {
  const _QuickActions({required this.onOpenModule});

  final void Function(String moduleId) onOpenModule;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.navy, AppColors.navyLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Wrap(
        spacing: 12,
        runSpacing: 12,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          const Text(
            'Quick actions',
            style: TextStyle(
              color: AppColors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: AppColors.sales),
            onPressed: () => onOpenModule('sale'),
            icon: const Icon(Icons.add_rounded),
            label: const Text('New Sale'),
          ),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: AppColors.purchases),
            onPressed: () => onOpenModule('purchase'),
            icon: const Icon(Icons.add_rounded),
            label: const Text('New Purchase'),
          ),
        ],
      ),
    );
  }
}

class _LowStockCard extends StatelessWidget {
  const _LowStockCard({required this.products});

  final List<Product> products;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.warning_amber_rounded, color: AppColors.stock),
                const SizedBox(width: 10),
                Text(
                  'Low-Stock Alerts',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ],
            ),
            const SizedBox(height: 14),
            if (products.isEmpty)
              const Text(
                'No low-stock items.',
                style: TextStyle(color: AppColors.textMuted),
              )
            else
              for (final p in products)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(p.name, overflow: TextOverflow.ellipsis),
                      ),
                      Text(
                        '${fmtQty(p.currentStock)} / min ${fmtQty(p.minStock)}',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color:
                              p.isNegative ? AppColors.reports : AppColors.stock,
                        ),
                      ),
                    ],
                  ),
                ),
          ],
        ),
      ),
    );
  }
}

class _EmptyListCard extends StatelessWidget {
  const _EmptyListCard({
    required this.title,
    required this.icon,
    required this.color,
    required this.message,
  });

  final String title;
  final IconData icon;
  final Color color;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color),
                const SizedBox(width: 10),
                Text(title, style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 14),
            Text(message, style: const TextStyle(color: AppColors.textMuted)),
          ],
        ),
      ),
    );
  }
}
