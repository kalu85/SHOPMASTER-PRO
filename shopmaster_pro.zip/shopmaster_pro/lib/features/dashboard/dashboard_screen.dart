import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../core/theme/app_colors.dart';
import '../../core/widgets/stat_card.dart';

/// Overview screen. All figures are zero until the database arrives in Phase 2+.
class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.onOpenModule});

  /// Navigates to a module by its id (see appModules).
  final void Function(String moduleId) onOpenModule;

  static final NumberFormat _inr =
      NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 2);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final columns = width >= 1100 ? 3 : (width >= 640 ? 2 : 1);
        const gap = 14.0;
        final cardWidth = (width - 32 - gap * (columns - 1)) / columns;

        final stats = <Widget>[
          StatCard(
            label: "Today's Sales",
            value: _inr.format(0),
            icon: Icons.trending_up_rounded,
            color: AppColors.sales,
            onTap: () => onOpenModule('sale'),
          ),
          StatCard(
            label: "Today's Purchases",
            value: _inr.format(0),
            icon: Icons.shopping_bag_rounded,
            color: AppColors.purchases,
            onTap: () => onOpenModule('purchase'),
          ),
          StatCard(
            label: 'Total Outstanding',
            value: _inr.format(0),
            icon: Icons.hourglass_bottom_rounded,
            color: AppColors.reports,
            onTap: () => onOpenModule('parties'),
          ),
          StatCard(
            label: 'Cash Balance',
            value: _inr.format(0),
            icon: Icons.payments_rounded,
            color: AppColors.bankUpi,
            onTap: () => onOpenModule('cashbank'),
          ),
          StatCard(
            label: 'Bank Balance',
            value: _inr.format(0),
            icon: Icons.account_balance_rounded,
            color: AppColors.suppliers,
            onTap: () => onOpenModule('cashbank'),
          ),
          StatCard(
            label: 'Total Stock Items',
            value: '0',
            icon: Icons.inventory_2_rounded,
            color: AppColors.stock,
            onTap: () => onOpenModule('stock'),
          ),
        ];

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _QuickActions(onOpenModule: onOpenModule),
            const SizedBox(height: 16),
            Wrap(
              spacing: gap,
              runSpacing: gap,
              children: [
                for (final s in stats) SizedBox(width: cardWidth, child: s),
              ],
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: gap,
              runSpacing: gap,
              children: [
                SizedBox(
                  width: columns == 1 ? width - 32 : (width - 32 - gap) / 2,
                  child: const _EmptyListCard(
                    title: 'Low-Stock Alerts',
                    icon: Icons.warning_amber_rounded,
                    color: AppColors.stock,
                    message: 'No items yet. Alerts appear once products are added.',
                  ),
                ),
                SizedBox(
                  width: columns == 1 ? width - 32 : (width - 32 - gap) / 2,
                  child: const _EmptyListCard(
                    title: 'Recent Invoices',
                    icon: Icons.description_rounded,
                    color: AppColors.sales,
                    message: 'No invoices yet.',
                  ),
                ),
                SizedBox(
                  width: width - 32,
                  child: const _EmptyListCard(
                    title: 'Recent Transactions',
                    icon: Icons.swap_horiz_rounded,
                    color: AppColors.bankUpi,
                    message: 'No transactions yet.',
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _QuickActions extends StatelessWidget {
  const _QuickActions({required this.onOpenModule});

  final void Function(String moduleId) onOpenModule;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.navy, AppColors.navyLight],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Wrap(
        spacing: 12,
        runSpacing: 12,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          const Text(
            'Quick actions',
            style: TextStyle(
              color: AppColors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: AppColors.sales),
            onPressed: () => onOpenModule('sale'),
            icon: const Icon(Icons.add_rounded),
            label: const Text('New Sale'),
          ),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: AppColors.purchases),
            onPressed: () => onOpenModule('purchase'),
            icon: const Icon(Icons.add_rounded),
            label: const Text('New Purchase'),
          ),
        ],
      ),
    );
  }
}

class _EmptyListCard extends StatelessWidget {
  const _EmptyListCard({
    required this.title,
    required this.icon,
    required this.color,
    required this.message,
  });

  final String title;
  final IconData icon;
  final Color color;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color),
                const SizedBox(width: 10),
                Text(title, style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 14),
            Text(message, style: const TextStyle(color: AppColors.textMuted)),
          ],
        ),
      ),
    );
  }
}
